package seleniumUIActions;

import java.io.IOException;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import resusableData.readtDataFromPropertiesFile;
import utils.driver.readDriver;

public class seleniumActions {

	public static void enterName() throws IOException
	{
		readDriver.driver.findElement(By.xpath(readtDataFromPropertiesFile.readdataforObjectReposiry("Register.ContactInformation.FirstName.inut"))).sendKeys("sneha");
	}
	
	public static void clickToHome() throws IOException
	{
		readDriver.driver.findElement(By.xpath(readtDataFromPropertiesFile.readdataforObjectReposiry("Resgister.Homepage.a"))).click();
	}
	
	public static void selectdropdown() {
		
		WebElement ele = readDriver.driver.findElement(By.xpath("//select[@name='country']"));
		Select selcet = new Select(ele);
		selcet.selectByValue("ANTAR");
		
		
	}
	
public static void switchtoframe() throws InterruptedException {
	
	  readDriver.driver.switchTo().frame("a077aa5e");	
		WebElement ele = readDriver.driver.findElement(By.xpath("//img[@src='Jmeter720.png']"));
	  JavascriptExecutor exe = (JavascriptExecutor)readDriver.driver;
	  exe.executeScript("arguments[0].click", ele);
	  Thread.sleep(3000);
		
		
	}
public static void switchtoalert() throws InterruptedException {
	
	 readDriver.driver.findElement(By.xpath("//input[@name='submit']")).click();
	 Alert alert = readDriver.driver.switchTo().alert();
	 
	 String alertmessage =  alert.getText();
	  System.out.println(alertmessage);
	 //alert.dismiss(); 
	 alert.accept();
	 String alertmessage1 =  alert.getText();
	  System.out.println(alertmessage1);
	  alert.accept();
		
	}

}

