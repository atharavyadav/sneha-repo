package utils.driver;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import resusableData.resusableData;

public class readDriver {
	public static WebDriver driver;
	public static void readBrowserDriver(String browsertrype,String path , String url) {
		
		if(resusableData.headless=="true")
		{
			ChromeOptions option = new ChromeOptions();
			option.addArguments("--headless");
			System.setProperty(browsertrype, path);
			 driver = new ChromeDriver(option);
			driver.manage().window().maximize();
			driver.get(url);
		}
		 
			System.setProperty(browsertrype, path);
			 driver = new ChromeDriver();
			driver.manage().window().maximize();
			driver.get(url);
		
		
	}
}
