package resusableData;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class readtDataFromPropertiesFile{

	public static String readdataforObjectReposiry(String key) throws IOException
	{
		File file = new File("D:\\eclipse\\CATT1.0\\ObjectRepository\\OR.properties");
		FileInputStream stream = new FileInputStream(file);
		Properties pro = new Properties();
		pro.load(stream);
		String readmydatabasedonKey = pro.getProperty(key);
		return readmydatabasedonKey;
		
	}
}
