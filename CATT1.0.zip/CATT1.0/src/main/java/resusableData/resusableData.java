package resusableData;

public interface resusableData {

	public static String url="https://demo.guru99.com/test/newtours/register.php";
	public static String switchtoframeurl="https://demo.guru99.com/test/guru99home/";
	public static String alertUrl="https://demo.guru99.com/test/delete_customer.php";
	public static String browsertype="webdriver.chrome.driver";
	public static String headless="false";
	public static String browserpath="D:\\eclipse\\CATT1.0\\driverPath\\chromedriver.exe";
	
}
