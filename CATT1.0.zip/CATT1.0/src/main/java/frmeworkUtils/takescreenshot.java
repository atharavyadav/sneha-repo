package frmeworkUtils;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import utils.driver.readDriver;

public class takescreenshot {
	
	
	public static void takeUIscreenshot(String screenshotname) throws IOException
	{
		TakesScreenshot sc = (TakesScreenshot)readDriver.driver;
		File file = sc.getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(file, new File("D:\\eclipse\\CATT1.0\\screenshots\\"+screenshotname+".png"));
	}

}
