package readbusTestCases;

import java.io.IOException;

import org.testng.annotations.Test;

import resusableData.resusableData;
import seleniumUIActions.seleniumActions;
import utils.driver.readDriver;

public class NavigatetoHomePage {
	@Test
	public void navigatingtoHome() throws IOException
	{
		readDriver.readBrowserDriver(resusableData.browsertype,resusableData.browserpath,resusableData.url);
	    seleniumActions.clickToHome();
	}

}
